
truncate table bmsql_warehouse;

truncate table bmsql_item;

truncate table bmsql_stock;

truncate table bmsql_district;

truncate table bmsql_customer;

truncate table bmsql_history;

truncate table bmsql_oorder;

truncate table bmsql_order_line;

truncate table bmsql_new_order;
